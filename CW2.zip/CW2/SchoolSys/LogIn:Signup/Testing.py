from django.test import TestCase
from django.urls import reverse

class UserTestCase(TestCase):
    def test_signup_form(self):
        data = {'username': 'testuser', 'password1': 'complexpassword', 'password2': 'complexpassword'}
        response = self.client.post(reverse('signup'), data)
        self.assertEqual(response.status_code, 302)  # Redirects after successful signup

    def test_login_form(self):
        self.client.post(reverse('signup'), {'username': 'testuser', 'password1': 'complexpassword', 'password2': 'complexpassword'})
        user_data = {'username': 'testuser', 'password': 'complexpassword'}
        response = self.client.post(reverse('login'), user_data)
        self.assertEqual(response.status_code, 302)  # Redirects after successful login
